//
//  GameScene.swift
//  FlappyClone
//
//  Created by Jared Davidson on 12/8/15.
//  Copyright (c) 2015 Archetapp. All rights reserved.
//

import SpriteKit

struct PhysicsCatagory {
    static let Ghost : UInt32 = 0x1 << 1
    static let Ground : UInt32 = 0x1 << 2
    static let SpaceShip : UInt32 = 0x1 << 5
    static let Missile : UInt32 = 0x1 << 3
    static let Satellite : UInt32 = 0x1 << 5
    static let DiamantBleu : UInt32 = 0x1 << 5
}



class GameScene: SKScene, SKPhysicsContactDelegate {
    
    
    var Ground = SKSpriteNode()
    var Ghost = SKSpriteNode()
    
    var SpaceShip = SKSpriteNode()
    var Missile = SKSpriteNode()
    var Satellite = SKSpriteNode()
    var DiamantBleu = SKSpriteNode()
    
    
    var moveAndRemove = SKAction()
    
    var gameStarted = Bool()
    
   
    var died = Bool()
    var restartBTN = SKSpriteNode()
    
    func restartScene(){
        
        self.removeAllChildren()
        self.removeAllActions()
        died = false
        gameStarted = false
        createScene()
        
    }
    
    
    // Ground
    func initGround(){
        Ground = SKSpriteNode(imageNamed: "Ground")
        Ground.setScale(0.5)
        Ground.position = CGPoint(x: self.frame.width / 2, y: 0 + Ground.frame.height / 2)
        
        Ground.physicsBody = SKPhysicsBody(rectangleOf: Ground.size)
        Ground.physicsBody?.categoryBitMask = PhysicsCatagory.Ground
        Ground.physicsBody?.collisionBitMask = PhysicsCatagory.Ghost
        Ground.physicsBody?.contactTestBitMask  = PhysicsCatagory.Ghost
        Ground.physicsBody?.affectedByGravity = false
        Ground.physicsBody?.isDynamic = false
        
        Ground.zPosition = 3
        self.addChild(Ground)

    }
    
    
    // SpaceShip
    func initSpaceShip(){
        
        SpaceShip = SKSpriteNode(imageNamed: "Spaceship")
        SpaceShip.size = CGSize(width: 60, height: 70)
        SpaceShip.position = CGPoint(x: self.frame.width / 2, y: 160)
        SpaceShip.setScale(0.7)
        
        SpaceShip.physicsBody = SKPhysicsBody(circleOfRadius: SpaceShip.frame.height / 2)
        SpaceShip.physicsBody?.categoryBitMask = PhysicsCatagory.SpaceShip
        
        SpaceShip.physicsBody?.affectedByGravity = true
        SpaceShip.physicsBody?.isDynamic = false
        
        SpaceShip.zPosition = 2
        
        self.addChild(SpaceShip)
    }
    
    
    // Diamant Bleu
    func initDiamantBleu(){
        DiamantBleu = SKSpriteNode(imageNamed: "DiamantBleu")
        DiamantBleu.size = CGSize(width: 20, height: 20)
        DiamantBleu.setScale(1.0)
        DiamantBleu.position = CGPoint(x: Ground.position.x+50, y: Ground.position.y+140)
        
        DiamantBleu.physicsBody = SKPhysicsBody(rectangleOf: DiamantBleu.size)
        DiamantBleu.physicsBody?.categoryBitMask = PhysicsCatagory.DiamantBleu
        DiamantBleu.physicsBody?.collisionBitMask = PhysicsCatagory.SpaceShip
        DiamantBleu.physicsBody?.contactTestBitMask = PhysicsCatagory.SpaceShip
        DiamantBleu.physicsBody?.affectedByGravity = false
        DiamantBleu.physicsBody?.isDynamic = true
        DiamantBleu.zPosition = 2
        
        self.addChild(DiamantBleu)
    }
    
    
    // Satelitte
    func initSatellite(){
        Satellite = SKSpriteNode(imageNamed: "satellite")
        Satellite.size = CGSize(width: 60, height: 70)
        Satellite.position = CGPoint(x: self.frame.width / 2, y: 100)
        Satellite.setScale(1.0)
        
        Satellite.physicsBody = SKPhysicsBody(circleOfRadius: Satellite.frame.height / 2)
        Satellite.physicsBody?.categoryBitMask = PhysicsCatagory.Satellite
        Satellite.physicsBody?.affectedByGravity = false
        Satellite.physicsBody?.isDynamic = false
        
        Satellite.zPosition = 2
        self.addChild(Satellite)
    }
    
    
    // Missile
    func initMissile(){
        Missile = SKSpriteNode(imageNamed: "Coin")
        Missile.size = CGSize(width: 2.0, height: 2.0)
        Missile.position = CGPoint(x: SpaceShip.position.x, y: SpaceShip.position.y)
        Missile.setScale(5.0)
        
        Missile.physicsBody = SKPhysicsBody(circleOfRadius: Missile.frame.height / 2)
        Missile.physicsBody?.categoryBitMask = PhysicsCatagory.Missile
        Missile.physicsBody?.collisionBitMask = PhysicsCatagory.Ghost
        Missile.physicsBody?.contactTestBitMask = PhysicsCatagory.Ghost
        Missile.physicsBody?.affectedByGravity = false
        Missile.physicsBody?.isDynamic = false
        
        Missile.zPosition = 2
        self.addChild(Missile)
    }
    
    
    // Ghost
    func initGhost(){
        Ghost = SKSpriteNode(imageNamed: "Ghost")
        Ghost.size = CGSize(width: 70, height: 80)
        Ghost.position = CGPoint(x: self.frame.width / 2 - Ghost.frame.width, y: self.frame.height / 2)
        Ghost.setScale(0.5)
        
        Ghost.physicsBody = SKPhysicsBody(circleOfRadius: Ghost.frame.height / 2)
        Ghost.physicsBody?.categoryBitMask = PhysicsCatagory.Ghost
        Ghost.physicsBody?.collisionBitMask = PhysicsCatagory.Ground
        Ghost.physicsBody?.contactTestBitMask = PhysicsCatagory.Ground
        Ghost.physicsBody?.affectedByGravity = false
        Ghost.physicsBody?.isDynamic = false  // Sinon, l'avion tourne autour du Ghost.
        
        Ghost.zPosition = 2
        
        self.addChild(Ghost)
    }
    
    
    // Create the Scene
    func createScene(){
        
        self.physicsWorld.contactDelegate = self
        
        for i in 0..<2 {
            let background = SKSpriteNode(imageNamed: "fond")
            background.anchorPoint = CGPoint.zero
            background.position = CGPoint(x: CGFloat(i) * self.frame.width, y: 0)
            background.name = "background"
            background.size = (self.view?.bounds.size)!
        
            self.addChild(background)
            
        }
        
        
        initGround()
        
        initSpaceShip()
        initDiamantBleu()
        initSatellite()
        initMissile()
        initGhost()
        
    }
    
    

    
    override func didMove(to view: SKView) {
        /* Setup your scene here */
        
        createScene()
        
    }
    
    func createBTN(){
        
        restartBTN = SKSpriteNode(imageNamed: "RestartBtn")
        restartBTN.size = CGSize(width: 200, height: 100)
        restartBTN.position = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2)
        restartBTN.zPosition = 6
        restartBTN.setScale(0)
        self.addChild(restartBTN)
        restartBTN.run(SKAction.scale(to: 1.0, duration: 0.3))
        
    }
    

    func didBegin(_ contact: SKPhysicsContact) {
     
        self.physicsWorld.contactDelegate = self;
        
        let contactMask = contact.bodyA.categoryBitMask
        
        if (contactMask==DiamantBleu.physicsBody?.categoryBitMask)
        {
            DiamantBleu.physicsBody?.affectedByGravity=true

        }
        
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gameStarted == false{
            
            gameStarted =  true
            
            Ghost.physicsBody?.affectedByGravity = true

            
            
            Ghost.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
            Ghost.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 90))
        }
        else{
            
            if died == true{
                
                
            }
            else{
                Ghost.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
                Ghost.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 90))
                
                
            
        }
        
        
        
        
        for touch in touches{
            let location = touch.location(in: self)
            
            if died == true{
                if restartBTN.contains(location){
                    restartScene()
                }
            }
                    
            
            // Get sprite's current position (a.k.a. starting point).
                    let currentPosition = SpaceShip.position
                    
                    // Calculate the angle using the relative positions of the sprite and touch.
                    let angle = atan2(currentPosition.y - location.y, currentPosition.x - location.x)
                    
                    // Define actions for the ship to take.
                    let rotateAction = SKAction.rotate(toAngle: angle + CGFloat(M_PI*0.5), duration: 0.0)
                    let moveAction = SKAction.move(to: location, duration: 1.0)
            
                let missileMoveAction = SKAction.move(to: SpaceShip.position, duration: 1.0)
                let satelliteMoveAction = SKAction.move(to: SpaceShip.position, duration: 0.5)
                    
                    // Tell the ship to execute actions.
                    SpaceShip.run(SKAction.sequence([rotateAction, moveAction]))
            
                Missile.run(SKAction.sequence([missileMoveAction]))
                Satellite.run(SKAction.sequence([satelliteMoveAction]))
            }
            
            
        }
        
        
        
        
        
        
    }
    


    
    
   
    override func update(_ currentTime: TimeInterval) {
        /* Called before each frame is rendered */
        
        if gameStarted == true{
            if died == false{
                enumerateChildNodes(withName: "background", using: ({
                    (node, error) in
                    
                    let bg = node as! SKSpriteNode
                    
                    bg.position = CGPoint(x: bg.position.x - 2, y: bg.position.y)
                    
                    if bg.position.x <= -bg.size.width {
                        bg.position = CGPoint(x: bg.position.x + bg.size.width * 2, y: bg.position.y)
                        
                    }
                    
                }))
                
            }
            
            
        }
        
        
        
        
    }
}
